#!/bin/bash

PREFIX=${PREFIX:=/usr/local}

DH_DEBUG=0
[[ $DH_DEBUG == 0 ]] && VERBOSE= || VERBOSE='-v';

source $PREFIX/etc/kdebuild/scripts/utils.sh
source $PREFIX/etc/kdebuild/scripts/setup_kdebuild.sh

set -eu

# Build Debian package for Host machine
echo_info "Building ${PACKAGE} v${VERSION} ${DISTNAME} package ..."

# Make and copy project to temporary directory to build packages
mkdir -p $PKGREPODIR
rsync -ar --exclude "*~"    \
          --exclude "__*"   \
          --exclude "*.out" \
          --exclude "*.swo" \
          --exclude "*.swp" \
          --exclude ".git*" \
          --exclude "$DISTDIR" \
          --exclude "$OBJDIR"  \
          --exclude "$BUILDDIR/$SOURCE_PKGSPECS" ./ $PKGREPODIR

# Copy package-specs to the build directory
cp -rpf $BUILDDIR/$SOURCE_PKGSPECS $PKGREPODIR/$TARGET_PKGSPECS
cd $PKGREPODIR
mkdir -p $DISTDIR

DH_RULES=(
	"dh_auto_clean"
	"dh_auto_build"
	"dh_prep"
	"dh_auto_install"
	"dh_install"
	"dh_installsystemd"
	"dh_link"
	"dh_compress"
	"dh_fixperms"
	"dh_strip"
	"dh_makeshlibs"
	"dh_shlibdeps"
	"dh_installdeb"
	"dh_gencontrol"
	"dh_md5sums"
	"dh_builddeb --destdir=${DISTDIR}"
)

# Build debian package
for DH_RULE in "${DH_RULES[@]}"
do
	echo_info "${DH_RULE}"
	fakeroot ${DH_RULE} ${VERBOSE}
done

cd - > /dev/null
mkdir -p $DISTDIR
# Move dpkg files to dist
cp -pvf $PKGREPODIR/$DISTDIR/*.deb $DISTDIR

exit 0

#EOF
