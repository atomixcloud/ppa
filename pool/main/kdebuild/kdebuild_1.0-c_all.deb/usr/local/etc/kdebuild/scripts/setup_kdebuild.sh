#!/bin/bash

set -eu

BUILDSPECS=build/scripts/buildspecs.in

if [ ! -f $BUILDSPECS ]; then
	echo "Kdebuild: cannot find buildspecs.in !!!"
	echo "          Are you in the source code tree ?"
	exit 1
fi

source $BUILDSPECS

NC=$(tput sgr0)
BOLD=$(tput bold)

OBJDIR=obj
DISTDIR=dist
BUILDDIR=build
PKGBUILDDIR=$BUILDDIR/$ELFNAME-build
DPKGARCH=$(dpkg --print-architecture)
PKGREPODIR=$PKGBUILDDIR/$ELFNAME-$RELEASE
TERMUX_TOOLCHAIN=$HOME/Projects/Toolchain/termux-toolchain
TERMUX_TOOLCHAIN_PKGDIR=$TERMUX_TOOLCHAIN/packages
TERMUX_PACKAGE_BUILDER=$TERMUX_TOOLCHAIN/build-package.sh

[[ -e $HOME/.termux ]] && PLATFORM="TERMUX" || PLATFORM="HOST";

if [ "$PLATFORM" == "TERMUX" ]; then
	SOURCE_PKGSPECS=termux-specs
	TARGET_PKGSPECS=termux
else
	SOURCE_PKGSPECS=debian-specs
	TARGET_PKGSPECS=debian
fi

if [ -f /etc/os-release ]; then
	DISTID=$(grep ID= /etc/os-release 2>/dev/null | grep -v _ID | cut -d '=' -f 2)
	if [ "$DISTID" == "ubuntu" ]; then
		DISTCODE=$(grep UBUNTU_CODENAME /etc/os-release 2>/dev/null | cut -d '=' -f 2)
	else
		DISTCODE=$(grep VERSION_CODENAME /etc/os-release 2>/dev/null | cut -d '=' -f 2)
	fi
else
	if [ "$PLATFORM" == "TERMUX" ]; then
		DISTCODE=termux
	fi
fi

DISTNAME=$(echo ${DISTCODE^})
DPKGNAME=${ELFNAME}_${VERSION}_${DPKGARCH}.deb

set +eu

#EOF
