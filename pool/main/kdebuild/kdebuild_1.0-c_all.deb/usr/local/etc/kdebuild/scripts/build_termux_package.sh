#!/bin/bash

# Build Termux package with Android-Termux toolchain

PREFIX=${PREFIX:=/usr/local}

source $PREFIX/etc/kdebuild/scripts/utils.sh
source $PREFIX/etc/kdebuild/scripts/setup_kdebuild.sh

echo_info "Building ${PACKAGE} v${VERSION} Termux Toolchain package ..."

if [ "$TERMUX_PKGNAME" == "" ]; then
	echo_error "Kdebuild: Termux variables is not configured !!!"
	exit 1
fi

set -eu

TOPDIR=$PWD
GITBRANCH=master
TERMUX_BUILD_FLAG=$HOME/.termux
TOOLCHAIN_GITREPO=$TOPDIR/$PKGREPODIR.git
TERMUX_BUILTDIR=/data/data/.built-packages
TERMUX_DPKG_NAME=${ELFNAME}_${VERSION}_aarch64.deb
TERMUX_TOOLCHAIN_BUILDDIR=$TERMUX_TOOLCHAIN_PKGDIR/$TERMUX_PKGNAME

clean_termux_build() {
	rm -rf $TERMUX_BUILD_FLAG \
	       $TOOLCHAIN_GITREPO \
	       $HOME/.termux-build/$ELFNAME \
	       $TERMUX_BUILTDIR/$TERMUX_PKGNAME \
	       $TERMUX_TOOLCHAIN_BUILDDIR/build.sh
}

if [ ! -f $TERMUX_PACKAGE_BUILDER ]; then
	echo_error "Kdebuild: missing Termux tool-chain !!!"
	exit 1
fi

# Make temporary repository to build
# packages with termux toolchain
mkdir -p $TOOLCHAIN_GITREPO

rsync -ar --exclude "*~"    \
          --exclude "__*"   \
          --exclude "*.out" \
          --exclude "*.swo" \
          --exclude "*.swp" \
          --exclude ".git*" \
          --exclude "$DISTDIR" \
          --exclude "$OBJDIR"  \
          --exclude "$BUILDDIR/$SOURCE_PKGSPECS" ./ $TOOLCHAIN_GITREPO

cd $TOOLCHAIN_GITREPO

#echo_info "Cloning repository ..."
git init   > /dev/null
git add -A > /dev/null
git commit -m "${PACKAGE} toolchain build commit" > /dev/null

cd - > /dev/null

sed -e "s#@__HOMEPAGE__@#$HOMEPAGE#g"              \
    -e "s#@__MAINTAINER__@#$MAINTAINER#g"          \
    -e "s#@__RELEASE__@#$RELEASE#g"                \
    -e "s#@__REVISION__@#$REVISION#g"              \
    -e "s#@__GITBRANCH__@#$GITBRANCH#g"            \
    -e "s#@__DESCRIPTION__@#$DESCRIPTION#g"        \
    -e "s#@__TERMUX_DEPENDS__@#$TERMUX_DEPENDS#g"  \
    -e "s#@__TOOLCHAIN_GITREPO__@#file://$TOOLCHAIN_GITREPO#g" \
       $TERMUX_TOOLCHAIN_BUILDDIR/build.in > $TERMUX_TOOLCHAIN_BUILDDIR/build.sh

# Build Termux package with toolchain
#echo_info "Running builder ..."
touch $TERMUX_BUILD_FLAG
eval $TERMUX_PACKAGE_BUILDER $TERMUX_PKGNAME
if [ $? -ne 0 ]; then
	echo_error "Failed to build package '$TERMUX_DPKG_NAME' !!!"
	clean_termux_build
	exit 1
fi

mkdir -p $DISTDIR
# Copy final output package to dist directory
cp -pvf $TERMUX_TOOLCHAIN/output/$ELFNAME*.deb $DISTDIR
clean_termux_build

exit 0

#EOF
