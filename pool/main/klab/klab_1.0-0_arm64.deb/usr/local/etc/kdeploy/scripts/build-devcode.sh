#!/bin/bash

source /usr/local/etc/kdeploy/scripts/utils.sh

BUILDOPTS=""
BUILDCMDS=compile_commands.json

usage() {
	cat <<-USAGE
	Usage: build-devcode [options] ...
	Build Devcode XREF of the project repository.

	Options:
	    -f  --force -- Generate cross references without compiling the project
	    -m  --make  -- Compile the project and generate cross references
	                   This will run 'make build && make && bear make' and 'build-devcode'
	    -h  --help  -- Display this help message
	USAGE

	exit 1
}

build_devcode_worker() {
	DIRPKGREPORT=__html
	PKGXREF=$DIRPKGREPORT/devcode
	PKGBUILDSPECS=build/scripts/buildspecs.in

	type codebrowser_generator > /dev/null 2>&1
	if [ $? -ne 0 ]; then
		echo "Codebrowser is not installed !!!"
		echo "Try 'sudo apt install codebrowser' and try again."
	fi

	if [ -f $PKGBUILDSPECS ]; then
		PKGELFNAME=$(grep 'ELFNAME=' $PKGBUILDSPECS | cut -f 2 -d '=')
	else
		PKGELFNAME=$(basename "$PWD")
		#read -rp 'Enter project name : ' PKGELFNAME
		#if [ "$PKGELFNAME" == "" ]; then
		#	echo -e "\nInvalid project name !!!"
		#	return 1
		#fi
	fi

	if [ "$BUILDOPTS" != "force" ]; then
		# Validate compile_commands
		if [ ! -f $BUILDCMDS ]; then
			echo -e "Build rule doesn't exist !!! ($BUILDCMDS)"
			echo -e "Run 'bear make' to generate build rule or try again."
			return 1
		fi
	fi

	PKGXREF=$DIRPKGREPORT/devcode

	# Create target directory
	mkdir -p $DIRPKGREPORT

	# Build devcode source files
	if [ -f $BUILDCMDS ]; then
		SRCS="$(jq '.[] | .file' < $BUILDCMDS | tr '\n' ' ')"
		if [ -z "$SRCS" ]; then
			kdeploy_error "Devcode" "No C or C++ source files found."
			return 1
		else
			codebrowser_generator -a -b "$BUILDCMDS" -p "$PKGELFNAME":"$PWD" -o "$PKGXREF" && \
			codebrowser_indexgenerator -p "$PKGELFNAME":"$PWD" "$PKGXREF"
		fi
	else
		codebrowser_generator -o "$PKGXREF" -p "$PKGELFNAME":"$PWD" "$PWD" -- && \
		codebrowser_indexgenerator -p "$PKGELFNAME":"$PWD" "$PKGXREF"
		echo -e "\nBuilt devcode without build commands !!! ($BUILDCMDS)"
	fi

	# Copying CSS assets handled in the caller

	return $?
}

parse_cmdline() {
	GETOPTS=$(getopt -o fmh --long force,make,help -- "$@")
	if [ "$?" != "0" ]; then
		echo "Try 'build-devcode --help' for more information."
		exit 1
	fi

	eval set -- "$GETOPTS"
	while :
	do
		case "$1" in
			-f | --force)
				BUILDOPTS='force'; shift;
				;;
			-m | --make)
				BUILDOPTS='make'; shift;
				;;
			-h | --help)
				usage; shift ;;
			--) shift; break ;; # -- means the End of the arguments
			*) echo "Unexpected option: $1" # will not hit here
		esac
	done

	#echo "Remaining arguments: $@"
}

build_devcode_handler() {
	local RETVAL=""

	#echo_warn "\nGenerating Devcode ..."

	if [ "$BUILDOPTS" == "make" ]; then
		if [ ! -f $BUILDCMDS ]; then
			bear make
		fi
	fi

	# Build XREF
	build_devcode_worker
	RETVAL=$?

	return $RETVAL
}

### Main procedure ####

parse_cmdline "$@"

[[ $# -lt 1 ]] && \
	BUILDOPTS='make';

build_devcode_handler

exit $?
