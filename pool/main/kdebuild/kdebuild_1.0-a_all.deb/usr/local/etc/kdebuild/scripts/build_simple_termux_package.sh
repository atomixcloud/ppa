#!/bin/bash

set -eu

source ./make/mkconfigs.sh

# If Android and Termux SDKs installed, then build package with toolchain
if [ -e $TERMUX_TOOLCHAIN ]; then
	exec ./build/scripts/build_aarch64_packages.sh
elif [ ! -e $HOME/.termux ]; then
	echo "${BOLD}${PACKAGE}: Build environment is not a Termux platform !!!${NC}"
	exit 0
fi

AR=llvm-ar
ARFLAGS=cr

DEBIAN_PKGSPECS=$PKGBUILDDIR/$TARGET_PKGSPECS
DEBIAN_PKGDIR=$DEBIAN_PKGSPECS/package
DEBIAN_INSTALLDIR=$TOPDIR/$DEBIAN_PKGSPECS/$ELFNAME

mkdir -p $PKGBUILDDIR
cp -rpf $BUILDDIR/$SOURCE_PKGSPECS $DEBIAN_PKGSPECS
mkdir -p $DEBIAN_PKGDIR
mkdir -p $DEBIAN_INSTALLDIR

make && make install DESTDIR=$DEBIAN_INSTALLDIR

cd $DEBIAN_INSTALLDIR
echo -e "\ntar: $DEBIAN_PKGDIR/data.tar.xz"
tar -vcJf $TOPDIR/$DEBIAN_PKGDIR/data.tar.xz -H gnu .

cd ../DEBIAN
echo -e "\ntar: $DEBIAN_PKGDIR/control.tar.xz"
tar -vcJf $TOPDIR/$DEBIAN_PKGDIR/control.tar.xz -H gnu .
echo "2.0" > "$TOPDIR/$DEBIAN_PKGDIR/debian-binary"
cd $TOPDIR

mkdir -p $DISTDIR
# Create the actual .deb file:
echo -e "\n$AR: $DISTDIR/$DPKGNAME"
$AR $ARFLAGS "$TOPDIR/$DISTDIR/$DPKGNAME"            \
             "$TOPDIR/$DEBIAN_PKGDIR/debian-binary"  \
             "$TOPDIR/$DEBIAN_PKGDIR/control.tar.xz" \
             "$TOPDIR/$DEBIAN_PKGDIR/data.tar.xz"

echo "dpkg-deb: building package '$ELFNAME' in '$DISTDIR/$DPKGNAME'."

exit 0

#EOF
