#!/bin/bash

FMTNC='\033[0m'
FMTBRED='\033[1;31m'
FMTBGRN='\033[1;32m'
FMTBYLW='\033[1;33m'
FMTBBLUE='\033[1;34m'
FMTBMGTA='\033[1;35m'
FMTBCYAN='\033[1;36m'

echo_info() {
	echo -e "${FMTBBLUE}$@${FMTNC}"
}

echo_warn() {
	echo -e "${FMTBYLW}$@${FMTNC}" >&2
}

echo_error() {
	echo -e "${FMTBRED}$@${FMTNC}" >&2
}

echo_cyan() {
	echo -e "${FMTBCYAN}$@${FMTNC}"
}

echo_notice() {
	echo -e "${FMTBMGTA}$@${FMTNC}"
}

kdeploy_error() {
	echo -e "${FMTBYLW}$1: ${FMTBRED}$2${FMTNC}" >&2
}

execv() {
	set -v

	eval "$@"
	EVAL=$?

	set +v

	return $EVAL
}

execit() {
	echo_warn "$@"

	eval "$@"
	EVAL=$?

	return $EVAL
}

#EOF
