
#ifndef __LOGIT_H__
#define __LOGIT_H__

#include <stdio.h>
#include <stdbool.h>

#define LOGIT_SET_CONSOLE 1

#define LOGIT_SET_ALL   0x00FF
#define LOGIT_SET_NONE  0x0000
#define LOGIT_SET_COMP  0x0001
#define LOGIT_SET_COMP1 0x00B2

#define LOGIT_SET_PID   (1 << 1)
#define LOGIT_SET_PPID  (1 << 2)
#define LOGIT_SET_DATE  (1 << 3)
#define LOGIT_SET_TIME  (1 << 4)
#define LOGIT_SET_LEVEL (1 << 5)
#define LOGIT_SET_FILE  (1 << 6)
#define LOGIT_SET_FUNC  (1 << 7)

#define logit_info(fmt...)  (logit(LOGIT_INFO,  fmt...))
#define logit_debug(fmt...) (logit(LOGIT_DEBUG, fmt...))
#define logit_trace(fmt...) (logit(LOGIT_TRACE, fmt...))
#define logit_warn(fmt...)  (logit(LOGIT_WARN,  fmt...))
#define logit_error(fmt...) (logit(LOGIT_ERROR, fmt...))
#define logit_fatal(fmt...) (logit(LOGIT_FATAL, fmt...))

#define logit(level, fmt...) (logit_handler(level, __FUNCTION__, __FILE__, __LINE__, fmt))
#define logit_printf(fmt, args...) (fprintf(stderr, "%s:%d %s() " fmt "\n", __FILE__, __LINE__, __func__, ##args))
#define __LOGIT_VARGS__ (const int level, const bool console, const char *caller, const char *file, const int lineno, const char *fmt, va_list ap)

/*
  The below enum sets the logit debug levels.
  FATAL < ERROR < WARN < NONE < INFO < DEBUG < TRACE
*/
enum {
    LOGIT_FATAL = -3,
    LOGIT_ERROR = -2,
    LOGIT_WARN  = -1,
    LOGIT_NONE  =  0,
    LOGIT_INFO  =  1,
    LOGIT_DEBUG =  2,
    LOGIT_TRACE =  3,
    LOGIT_MAX_LEVEL = LOGIT_TRACE
};


struct logit_st {
    int   level;                   /* Max log level            */
    int    mask;                   /* Mask value for flags     */
    int console;                   /* Console debug control    */
    FILE *logfp;                   /* Log file to write debugs */
    int  (*info) __LOGIT_VARGS__ ; /* INFO  level logs handler */
    int (*debug) __LOGIT_VARGS__ ; /* DEBUG level logs handler */
    int (*trace) __LOGIT_VARGS__ ; /* TRACE level logs handler */
    int  (*warn) __LOGIT_VARGS__ ; /* WARN  level logs handler */
    int (*error) __LOGIT_VARGS__ ; /* ERROR level logs handler */
    int (*fatal) __LOGIT_VARGS__ ; /* FATAL level logs handler */
} logit;

int init_logit(const char *logfile, const char *mode, const int level, int flags, const int console, char *attr);
int logit_handler(const int level, const char *caller, const char *file, const int line, const char *fmt, ...);

#endif

