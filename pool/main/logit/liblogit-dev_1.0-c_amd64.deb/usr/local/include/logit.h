
#ifndef __LIBLOGIT_H__
#define __LIBLOGIT_H__

#include <stdio.h>
#include <stdbool.h>

/* Logit console debug flag */
#define LOGIT_SET_CONSOLE 1

/* Logit predefined print formats */
#define LOGIT_SET_ALL   0x00FF /* Set this to print all fields in log file      */
#define LOGIT_SET_NONE  0x0000 /* Set this to print only the debug messages     */
#define LOGIT_SET_COMP  0x00A1 /* Set this to print pid|time|level|caller|file  */
#define LOGIT_SET_COMP1 0x00A2 /* Set this to print pid|time|caller|file        */
#define LOGIT_LDTRACE   0x00B1 /* Set this to enable debugging for LDLIBS       */

/* Logit print format flags */
#define LOGIT_SET_PID   (1 << 1)
#define LOGIT_SET_PPID  (1 << 2)
#define LOGIT_SET_DATE  (1 << 3)
#define LOGIT_SET_TIME  (1 << 4)
#define LOGIT_SET_LEVEL (1 << 5)
#define LOGIT_SET_FILE  (1 << 6)
#define LOGIT_SET_FUNC  (1 << 7)

/* Error handling macro APIs for general use */
#define logit_fatal(fmt...)   (logit(LOGIT_FATAL,   fmt))
#define logit_error(fmt...)   (logit(LOGIT_ERROR,   fmt))
#define logit_warn(fmt...)    (logit(LOGIT_WARN,    fmt))

/* Macro APIs for general use */
#define logit_info(fmt...)    (logit(LOGIT_INFO,    fmt))
#define logit_debug(fmt...)   (logit(LOGIT_DEBUG,   fmt))
#define logit_trace(fmt...)   (logit(LOGIT_TRACE,   fmt))
#define logit_verbose(fmt...) (logit(LOGIT_VERBOSE, fmt))

/* Macro APIs for error cases for libraries (recommended) */
#define logit_ldfatal(fmt...)   (logit_ld(LOGIT_LD_FATAL, fmt))
#define logit_lderror(fmt...)   (logit_ld(LOGIT_LD_ERROR, fmt))
#define logit_ldwarn(fmt...)    (logit_ld(LOGIT_LD_WARN,  fmt))

/* Macro APIs for libraries (recommended) */
#define logit_ldinfo(fmt...)    (logit_ld(LOGIT_LD_INFO,    fmt))
#define logit_lddebug(fmt...)   (logit_ld(LOGIT_LD_DEBUG,   fmt))
#define logit_ldtrace(fmt...)   (logit_ld(LOGIT_LD_TRACE,   fmt))
#define logit_ldverbose(fmt...) (logit_ld(LOGIT_LD_VERBOSE, fmt))

/* Logit conditional APIs */
#define DEBUG(x) ((debug == true) ? (x) : (0))
#define islogit(msg...) ((debug == true) ? (logit_debug(msg)) : (0))

/* Logit internal handlers */
#define logit(level, fmt...) (logit_handler(level, __FUNCTION__, __FILE__, __LINE__, fmt))

/* It is recommended to use logit_ld*() APIs for debugging libraries */
#define logit_ld(level, fmt...) (logit_ld_handler(level, __FUNCTION__, __FILE__, __LINE__, fmt))

#define logit_printf(fmt, args...) (fprintf(stderr, "%s:%d %s() " fmt "\n", __FILE__, __LINE__, __func__, ##args))
#define __LOGIT_VARGS__ (const int level, const bool console, const char *caller, const char *file, const int lineno, const char *fmt, va_list ap)

/*
  The below enum sets the logit debug levels.
  FATAL < ERROR < WARN < NONE < INFO < DEBUG < TRACE < VERBOSE
*/
enum {
	LOGIT_FATAL = -3,
	LOGIT_ERROR = -2,
	LOGIT_WARN  = -1,
	LOGIT_INFO  =  0,
	LOGIT_DEBUG =  1,
	LOGIT_TRACE =  2,
	LOGIT_VERBOSE = 3,
	LOGIT_UNKNOWN = 9,
	LOGIT_SET_MAX = LOGIT_VERBOSE
};

/* The following debug levels are recommended for libraries */
enum {
	LOGIT_LD_FATAL = -6,
	LOGIT_LD_ERROR = -5,
	LOGIT_LD_WARN  = -4,
	LOGIT_LD_INFO  =  5,
	LOGIT_LD_DEBUG =  6,
	LOGIT_LD_TRACE =  7,
	LOGIT_LD_VERBOSE = 8,
};

/* Logit core data structure */
typedef struct {
	int   level;                   /* Max debug level                   */
	int    mask;                   /* Mask value for flags              */
	int console;                   /* Console debug control             */
	FILE *logfp;                   /* Log file to write debugs          */
	int (*fatal) __LOGIT_VARGS__ ; /* FATAL level logs handler          */
	int (*error) __LOGIT_VARGS__ ; /* ERROR level logs handler          */
	int (*warn)  __LOGIT_VARGS__ ; /* WARN  level logs handler          */
	int (*info)  __LOGIT_VARGS__ ; /* INFO  level logs handler          */
	int (*debug) __LOGIT_VARGS__ ; /* DEBUG level logs handler          */
	int (*trace) __LOGIT_VARGS__ ; /* TRACE level logs handler          */

	/* The following parameters are specific to libraries               */
	int ldtrace;                   /* Set this to enable LDLIBS logger  */
	int ldtrace_level;             /* Max debug level for LDLIBS logger */
	int (*verbose)    __LOGIT_VARGS__ ;
	int (*ld_fatal)   __LOGIT_VARGS__ ;
	int (*ld_error)   __LOGIT_VARGS__ ;
	int (*ld_warn)    __LOGIT_VARGS__ ;
	int (*ld_info)    __LOGIT_VARGS__ ;
	int (*ld_debug)   __LOGIT_VARGS__ ;
	int (*ld_trace)   __LOGIT_VARGS__ ;
	int (*ld_verbose) __LOGIT_VARGS__ ;
} logit_t;

extern logit_t logit;

/* Logit core interfaces */
int logit_handler(const int level, const char *caller, const char *file, const int line, const char *fmt, ...);
int logit_ld_handler(const int level, const char *caller, const char *file, const int line, const char *fmt, ...);
int init_logit(const char *logfile, const char *mode, const int level, int flags, const int console, int (*attr)(void));

#endif /* EOF */
