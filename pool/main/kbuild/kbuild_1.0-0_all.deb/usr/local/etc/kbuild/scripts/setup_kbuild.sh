#!/bin/bash

set -eu

NC=$(tput sgr0)
BOLD=$(tput bold)

OBJDIR=obj
DISTDIR=dist
KTAGDIR=.ktags
BUILDDIR=kbuild
CODEREVIEW=codereview
PKGBUILDDIR=$BUILDDIR/$ELFNAME-build
PKGREPODIR=$PKGBUILDDIR/$ELFNAME-$RELEASE
TERMUX_TOOLCHAIN=$HOME/Projects/Toolchain/termux-toolchain

[[ -e $HOME/.termux ]] && PLATFORM="TERMUX" || PLATFORM="HOST";

if [ "$PLATFORM" == "TERMUX" ]; then
	SOURCE_PKGSPECS=termux-specs
	TARGET_PKGSPECS=termux
else
	SOURCE_PKGSPECS=debian-specs
	TARGET_PKGSPECS=debian
fi

if [ -f /etc/os-release ]; then
	DISTID=$(grep ID= /etc/os-release 2>/dev/null | grep -v _ID | cut -d '=' -f 2)
	if [ "$DISTID" == "ubuntu" ]; then
		DISTCODE=$(grep UBUNTU_CODENAME /etc/os-release 2>/dev/null | cut -d '=' -f 2)
	else
		DISTCODE=$(grep VERSION_CODENAME /etc/os-release 2>/dev/null | cut -d '=' -f 2)
	fi
else
	if [ "$PLATFORM" == "TERMUX" ]; then
		DISTCODE=termux
	fi
fi

DISTNAME=$(echo ${DISTCODE^})
DPKGNAME=${ELFNAME}_${VERSION}_${ARCH}.deb

#EOF
