#!/bin/bash

set -eu

DIRKLAB=/var/klab/public
PREFIX=${PREFIX:=/usr/local}
ETCKDEPLOY=$PREFIX/etc/kdeploy
DIRKDEPLOY=$DIRKLAB/deployments
ETCSCRIPTS=$PREFIX/etc/kdeploy/scripts

source $ETCSCRIPTS/utils.sh

install_deployment_mainpage() {
	local TARGET_TITLE="$1"
	local TARGET_FILE="$2"
	local TARGET_ICON="$3"

	if [ $# -lt 2 ]; then
		echo "ERROR: install_deployment_mainpage() invalid arguments !!!"
		return 1
	fi

	if [ -z "$TARGET_FILE" ]; then
		echo "ERROR: Invalid deployment target index file name !!!"
		return 1
	fi

	sed -e "s#@__INDEX_TITLE__@#$TARGET_TITLE#g" \
	    -e "s#@__INDEX_ICON__@#$TARGET_ICON#g"   \
	       $ETCKDEPLOY/www/kdeploy-index.php.in > "$TARGET_FILE"
}

setup_kdeploy() {
	if [ $UID -ne 0 ]; then
		echo "This script must be run as root." 1>&2
		exit 1
	fi

	# Create deployment directories
	mkdir -p $DIRKDEPLOY/{codereview,devcode,doxygen,gitstats,khelp/tags}

	# Install Khelp index file
	cp -f $ETCKDEPLOY/www/khelp-index.php.in $DIRKDEPLOY/khelp/index.php

	# func <title> <target-index-file> <icon-file>
	if [ ! -f "$DIRKDEPLOY/codereview/index.php" ]; then
		install_deployment_mainpage "Codereview Deployments" "$DIRKDEPLOY/codereview/index.php" "../../icons/vendor/codereview.png"
	fi

	if [ ! -f "$DIRKDEPLOY/devcode/index.php" ]; then
		install_deployment_mainpage "Devcode Deployments" "$DIRKDEPLOY/devcode/index.php" "../../icons/vendor/devcode.png"
	fi

	if [ ! -f "$DIRKDEPLOY/doxygen/index.php" ]; then
		install_deployment_mainpage "Doxygen Deployments" "$DIRKDEPLOY/doxygen/index.php" "../../icons/vendor/doxygen.png"
	fi

	if [ ! -f "$DIRKDEPLOY/gitstats/index.php" ]; then
		install_deployment_mainpage "Gitstats Deployments" "$DIRKDEPLOY/gitstats/index.php" "../../icons/vendor/gitstats.png"
	fi
}

setup_kdeploy;

set +e

#EOF
