#!/data/data/com.termux/files/usr/bin/bash

source /usr/local/etc/kdeploy/scripts/utils.sh

SRCS=""
DIRTARGET=__html/codereview
BUILDCMDS=compile_commands.json

# Get source files with bear-make output
get_build_source_jq() {
	local files=""
	local json_data=""

	json_data=$(cat $BUILDCMDS)

	# Extract the directory and file information for each object in the JSON array
	for obj in $(echo "${json_data}" | jq -c '.[]'); do
		directory=$(echo "${obj}" | jq -r '.directory')
		file=$(echo "${obj}" | jq -r '.file')
		files="${files} ${directory}/${file}"
	done

	# Return source files
	echo "${files}"
}

# Get source files by parsing make dry-run (make -n) output
get_build_source() {
	local c_file=""
	local output=""

	# Run a dry run of make and capture the output
	while read -r line; do
		# Check if the line contains a .c file
		if [[ "$line" == *"cc "* || "$line" == *"gcc "* ]] && [[ "$line" == *"-c "* ]] && [[ "$line" == *".c"* ]]; then
			# Extract the full path of the .c file and append it to the output string
			c_file=$(echo "$line" | sed 's/^.* \([^\ ]*\.c\).*$/\1/')
			output="$output $c_file"
		fi
	done < <(make -n)

	# Remove leading and trailing whitespace from the output string
	output=$(echo "$output" | sed 's/^[[:space:]]*//;s/[[:space:]]*$//')

	# Return the output string
	echo "$output"
}

generate_cppcheck_report() {
	printf "CPPcheck   : Analyzing source code ... "

	# Generate XML report
	if ! cppcheck --quiet --enable=all --xml --xml-version=2 $SRCS 2> $DIRTARGET/cppcheck-report.xml; then
		kdeploy_error "CPPcheck" "Failed to generate XML report !!!"
		return 1
	fi

	# Generate HTML report from the XML output
	if ! cppcheck-htmlreport --title='Static source-code analysis' \
	                         --report-dir=$DIRTARGET \
	                         --file=$DIRTARGET/cppcheck-report.xml 1> $DIRTARGET/cppcheck.log; then
		kdeploy_error "CPPcheck" "Failed to generate HTML report !!!"
		return 1
	fi

	# Process HTML files
	mv $DIRTARGET/index.html $DIRTARGET/cppcheck-report.html
	rm -f $DIRTARGET/cppcheck-report.xml

	printf "\rCPPcheck   : Report generated %s\n" "$DIRTARGET/cppcheck-report.html"

	return 0
}

generate_flawfinder_report() {
	printf "Flaw-Finder: Analyzing source code ... "

	# Generate HTML report
	if ! flawfinder --html --context $SRCS > $DIRTARGET/flawfinder-report.html; then
		kdeploy_error "Flaw-Finder" "Failed to generate report !!!"
		return 1
	fi

	printf "\rFlaw-Finder: Report generated %s\n" "$DIRTARGET/flawfinder-report.html"

	return 0
}

codereview_worker() {
	#echo_warn "\nGenerating Codereview ..."

	if [ ! -f $BUILDCMDS ]; then
		bear make
	fi

	SRCS="$(get_build_source_jq)"

	# Validate input source files
	if [ -z "$SRCS" ]; then
		kdeploy_error "Codereview" "No C or C++ source files found."
		return 1
	fi

	mkdir -p $DIRTARGET

	# Generate CPPcheck
	if ! generate_cppcheck_report; then
		return 1
	fi

	# Generate Flawfinder
	if ! generate_flawfinder_report; then
		return 1
	fi

	# Copy Index file
	if [ -f /usr/local/etc/kdeploy/www/codereview-index.html ]; then
		cp -f /usr/local/etc/kdeploy/www/codereview-index.html $DIRTARGET/index.html
	fi

	return 0
}

# Main procedure
codereview_worker

exit $?
