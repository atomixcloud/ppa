#!/bin/bash

: ${PREFIX:=/usr/local}

set -eu

DH_DEBUG=0
[[ $DH_DEBUG == 0 ]] && VERBOSE= || VERBOSE='-v';

source ./kbuild/scripts/buildspecs.in
source $PREFIX/etc/kbuild/scripts/setup_kbuild.sh

# Build Debian package for Host machine
echo "${BOLD}Building ${PACKAGE} v${VERSION} ${DISTNAME} package ...${NC}"

# Make and copy project to temporary directory to build packages
mkdir -p $PKGREPODIR
rsync -ar --exclude "*~"    \
          --exclude "*.out" \
          --exclude "*.swp" \
          --exclude "*.swo" \
          --exclude ".git*" \
          --exclude "$OBJDIR"   \
          --exclude "$KTAGDIR"  \
          --exclude "$DISTDIR"  \
          --exclude "$CODEREVIEW" \
          --exclude "$ELFNAME.out" ./ $PKGREPODIR

# Copy package-specs to the build directory
cp -rpf $BUILDDIR/$SOURCE_PKGSPECS $PKGREPODIR/$TARGET_PKGSPECS
cd $PKGREPODIR
mkdir -p $DISTDIR

DH_RULES=(
	"dh_auto_clean"
	"dh_auto_build"
	"dh_prep"
	"dh_auto_install"
	"dh_install"
	"dh_installsystemd"
	"dh_link"
	"dh_compress"
	"dh_fixperms"
	"dh_strip"
	"dh_makeshlibs"
	"dh_shlibdeps"
	"dh_installdeb"
	"dh_gencontrol"
	"dh_md5sums"
	"dh_builddeb --destdir=${DISTDIR}"
)

# Build debian package
for DH_RULE in "${DH_RULES[@]}"
do
	echo "${BOLD}${DH_RULE}${NC}"
	fakeroot ${DH_RULE} ${VERBOSE}
done

cd - > /dev/null
mkdir -p $DISTDIR
# Move dpkg files to dist
cp -pvf $PKGREPODIR/$DISTDIR/*.deb $DISTDIR
cp -pvf $PKGREPODIR/$DISTDIR/*.ddeb $DISTDIR

exit 0

#EOF
