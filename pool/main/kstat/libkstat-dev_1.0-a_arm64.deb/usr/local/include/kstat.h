
#ifndef __KSTAT_H__
#define __KSTAT_H__

#define LIBKSTAT_VERSION "1.0-a"

#include <stdio.h>
#include <stdlib.h>
#include <limits.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <libgen.h>
#include <magic.h>
#include <assert.h>
#include <time.h>
#include <sys/sysmacros.h>
#include <pwd.h>

#define BUFFSIZE 512
#define NAME_LEN 256
#define EXTN_LEN 8
#define MIME_LEN 32

typedef struct kstat_st {
	char realname[NAME_LEN];  /* Filename from root path */
	char dirname[NAME_LEN];   /* Parent directory */
	char barename[NAME_LEN];  /* Basename without extension */
	char basename[NAME_LEN];  /* Basename with extension */
	char extension[EXTN_LEN]; /* File extension */
	char mimetype[MIME_LEN];  /* Full mimetype 'main-type/sub-type' */
	char type[MIME_LEN];      /* 'main-type of the mimetype */
	char subtype[MIME_LEN];   /* 'subtype of the mimetype */

	/* Linux stat() components */
	dev_t     devid;        /* ID of device containing file */
	ino_t     inode;        /* Inode number */
	mode_t    mode;         /* File type and mode */
	nlink_t   nlink;        /* Number of hard links */
	uid_t     uid;          /* User ID of owner */
	gid_t     gid;          /* Group ID of owner */
	dev_t     rdev;         /* Device ID (if special file) */
	size_t    size;         /* Total size, in bytes */
	blksize_t blksize;      /* Block size for filesystem I/O */
	blkcnt_t  blocks;       /* Number of 512B blocks allocated */
	struct timespec atime;  /* Time of last access */
	struct timespec mtime;  /* Time of last modification */
	struct timespec ctime;  /* Time of last status change */
} kstat_t;

int printkstatbuff(kstat_t *sb);
int kstat(const char *file, kstat_t *sb);
char *kstat_strfilemode(const unsigned long mode);

#endif

