#!/bin/bash

# Build Termux package with Android-Termux toolchain

: ${PREFIX:=/usr/local}

set -eu

TOPDIR=$PWD
touch $HOME/.termux

source ./build/scripts/buildspecs.in
source $PREFIX/etc/kdebuild/scripts/setup_kdebuild.sh

echo "${BOLD}Building ${PACKAGE} v${VERSION} Termux Toolchain package ...${NC}"

GITBRANCH=master
TOOLCHAIN_GITREPO=$TOPDIR/$PKGREPODIR.git
TERMUX_BUILTDIR=/data/data/.built-packages
TERMUX_DPKG_NAME=${ELFNAME}_${VERSION}_aarch64.deb
TERMUX_TOOLCHAIN_PKGDIR=$TERMUX_TOOLCHAIN/packages
TERMUX_TOOLCHAIN_BUILDDIR=$TERMUX_TOOLCHAIN_PKGDIR/$TERMUX_PKGNAME

# Make temporary repository to build
# packages with termux toolchain
mkdir -p $TOOLCHAIN_GITREPO

rsync -ar --exclude "*~"        \
          --exclude "*.out"     \
          --exclude "*.swp"     \
          --exclude "*.swo"     \
          --exclude ".git*"     \
          --exclude "$KTAGDIR"  \
          --exclude "$DISTDIR"  \
          --exclude "$OBJDIR"   \
          --exclude "$CODEREVIEW" \
            ./ $TOOLCHAIN_GITREPO

cd $TOOLCHAIN_GITREPO

echo "Cloning local repository ..."
git init   > /dev/null
git add -A > /dev/null
git commit -m "${PACKAGE} toolchain build commit" > /dev/null

cd - > /dev/null

sed -e "s#@__HOMEPAGE__@#$HOMEPAGE#g"              \
    -e "s#@__MAINTAINER__@#$MAINTAINER#g"          \
    -e "s#@__RELEASE__@#$RELEASE#g"                \
    -e "s#@__REVISION__@#$REVISION#g"              \
    -e "s#@__GITBRANCH__@#$GITBRANCH#g"            \
    -e "s#@__DESCRIPTION__@#$DESCRIPTION#g"        \
    -e "s#@__TERMUX_DEPENDS__@#$TERMUX_DEPENDS#g"  \
    -e "s#@__TOOLCHAIN_GITREPO__@#file://$TOOLCHAIN_GITREPO#g" \
       $TERMUX_TOOLCHAIN_BUILDDIR/build.in > $TERMUX_TOOLCHAIN_BUILDDIR/build.sh

# Build Termux package with toolchain
eval $TERMUX_TOOLCHAIN/build-package.sh $TERMUX_PKGNAME
if [ $? -ne 0 ]; then
	echo "Failed to build package '$TERMUX_DPKG_NAME' !!!"
	exit 1
fi

rm -rf $HOME/.termux                    \
       $TOOLCHAIN_GITREPO               \
       $HOME/.termux-build/$ELFNAME     \
       $TERMUX_BUILTDIR/$TERMUX_PKGNAME \
       $TERMUX_TOOLCHAIN_BUILDDIR/build.sh

# Uncomment below line to build package with fresh dependecies
#rm -rf $HOME/.termux-build

mkdir -p $DISTDIR
# Copy final output package to dist directory
cp -pvf $TERMUX_TOOLCHAIN/output/$ELFNAME*.deb $DISTDIR

exit 0

#EOF
